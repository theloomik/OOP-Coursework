set(__QT_DEPLOY_TARGET_VetPet_FILE C:/Users/Lenovo/Documents/GitHub/OOP-Coursework/VetPet/VetPet/build-codex/VetPet.exe)
set(__QT_DEPLOY_TARGET_VetPet_TYPE EXECUTABLE)
set(__QT_DEPLOY_TARGET_VetPet_RUNTIME_DLLS C:/QT/6.11.0/mingw_64/bin/Qt6Widgets.dll;C:/QT/6.11.0/mingw_64/bin/Qt6Sql.dll;C:/QT/6.11.0/mingw_64/bin/Qt6Gui.dll;C:/QT/6.11.0/mingw_64/bin/Qt6Core.dll)
