# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "")
  file(REMOVE_RECURSE
  "CMakeFiles\\VetPet_autogen.dir\\AutogenUsed.txt"
  "CMakeFiles\\VetPet_autogen.dir\\ParseCache.txt"
  "VetPet_autogen"
  )
endif()
