/********************************************************************************
** Form generated from reading UI file 'appointmentsview.ui'
**
** Created by: Qt User Interface Compiler version 6.11.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_APPOINTMENTSVIEW_H
#define UI_APPOINTMENTSVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AppointmentsView
{
public:
    QVBoxLayout *mainLayout;
    QLabel *titleLabel;
    QHBoxLayout *searchLayout;
    QLineEdit *searchEdit;
    QPushButton *sortBtn;
    QHBoxLayout *headerLayout;
    QLabel *headerDate;
    QSpacerItem *h1;
    QLabel *headerClient;
    QSpacerItem *h2;
    QLabel *headerPet;
    QSpacerItem *h3;
    QLabel *headerStatus;
    QSpacerItem *h4;
    QLabel *emptyLabel;
    QScrollArea *listScroll;
    QWidget *listContainer;
    QVBoxLayout *listLayout;

    void setupUi(QWidget *AppointmentsView)
    {
        if (AppointmentsView->objectName().isEmpty())
            AppointmentsView->setObjectName("AppointmentsView");
        mainLayout = new QVBoxLayout(AppointmentsView);
        mainLayout->setObjectName("mainLayout");
        mainLayout->setContentsMargins(30, 25, 30, 25);
        titleLabel = new QLabel(AppointmentsView);
        titleLabel->setObjectName("titleLabel");

        mainLayout->addWidget(titleLabel);

        searchLayout = new QHBoxLayout();
        searchLayout->setSpacing(10);
        searchLayout->setObjectName("searchLayout");
        searchLayout->setContentsMargins(-1, -1, -1, 20);
        searchEdit = new QLineEdit(AppointmentsView);
        searchEdit->setObjectName("searchEdit");

        searchLayout->addWidget(searchEdit);

        sortBtn = new QPushButton(AppointmentsView);
        sortBtn->setObjectName("sortBtn");
        sortBtn->setMinimumSize(QSize(86, 42));
        sortBtn->setMaximumSize(QSize(86, 42));

        searchLayout->addWidget(sortBtn);


        mainLayout->addLayout(searchLayout);

        headerLayout = new QHBoxLayout();
        headerLayout->setObjectName("headerLayout");
        headerLayout->setContentsMargins(10, -1, 10, 8);
        headerDate = new QLabel(AppointmentsView);
        headerDate->setObjectName("headerDate");
        headerDate->setMinimumSize(QSize(170, 0));
        headerDate->setAlignment(Qt::AlignCenter);

        headerLayout->addWidget(headerDate);

        h1 = new QSpacerItem(10, 20, QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Minimum);

        headerLayout->addItem(h1);

        headerClient = new QLabel(AppointmentsView);
        headerClient->setObjectName("headerClient");
        headerClient->setMinimumSize(QSize(170, 0));
        headerClient->setAlignment(Qt::AlignCenter);

        headerLayout->addWidget(headerClient);

        h2 = new QSpacerItem(10, 20, QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Minimum);

        headerLayout->addItem(h2);

        headerPet = new QLabel(AppointmentsView);
        headerPet->setObjectName("headerPet");
        headerPet->setMinimumSize(QSize(130, 0));
        headerPet->setAlignment(Qt::AlignCenter);

        headerLayout->addWidget(headerPet);

        h3 = new QSpacerItem(10, 20, QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Minimum);

        headerLayout->addItem(h3);

        headerStatus = new QLabel(AppointmentsView);
        headerStatus->setObjectName("headerStatus");
        headerStatus->setMinimumSize(QSize(130, 0));
        headerStatus->setAlignment(Qt::AlignCenter);

        headerLayout->addWidget(headerStatus);

        h4 = new QSpacerItem(40, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        headerLayout->addItem(h4);


        mainLayout->addLayout(headerLayout);

        emptyLabel = new QLabel(AppointmentsView);
        emptyLabel->setObjectName("emptyLabel");
        emptyLabel->setAlignment(Qt::AlignCenter);
        emptyLabel->setVisible(false);

        mainLayout->addWidget(emptyLabel);

        listScroll = new QScrollArea(AppointmentsView);
        listScroll->setObjectName("listScroll");
        listScroll->setWidgetResizable(true);
        listScroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        listContainer = new QWidget();
        listContainer->setObjectName("listContainer");
        listLayout = new QVBoxLayout(listContainer);
        listLayout->setSpacing(0);
        listLayout->setObjectName("listLayout");
        listLayout->setContentsMargins(0, 0, 0, 0);
        listScroll->setWidget(listContainer);

        mainLayout->addWidget(listScroll);


        retranslateUi(AppointmentsView);

        QMetaObject::connectSlotsByName(AppointmentsView);
    } // setupUi

    void retranslateUi(QWidget *AppointmentsView)
    {
        AppointmentsView->setStyleSheet(QCoreApplication::translate("AppointmentsView", "\n"
"    QLabel#titleLabel { color: #FFFFFF; font-size: 26px; font-weight: bold; }\n"
"    QLabel.headerLabel { color: #757575; font-size: 12px; font-weight: 600; }\n"
"    QLineEdit#searchEdit { background-color: #3A3A3A; color: #FFFFFF; border: none; border-radius: 10px; padding: 0 14px; min-height: 42px; }\n"
"    QPushButton#sortBtn { background-color: #3A3A3A; color: #FFFFFF; border: none; border-radius: 10px; font-weight: bold; }\n"
"    QLabel#emptyLabel { color: #999999; font-size: 15px; }\n"
"    QScrollArea#listScroll { background-color: transparent; border: none; }\n"
"   ", nullptr));
        titleLabel->setText(QCoreApplication::translate("AppointmentsView", "\320\227\320\260\320\277\320\270\321\201\320\270", nullptr));
        searchEdit->setPlaceholderText(QCoreApplication::translate("AppointmentsView", "\320\237\320\276\321\210\321\203\320\272 (\321\202\320\265\320\273\320\265\321\204\320\276\320\275, \320\237\320\206\320\221 \320\272\320\273\321\226\321\224\320\275\321\202\320\260, \320\272\320\273\320\270\321\207\320\272\320\260)", nullptr));
        sortBtn->setText(QCoreApplication::translate("AppointmentsView", "\320\224\320\260\321\202\320\260 \342\206\221", nullptr));
        headerDate->setText(QCoreApplication::translate("AppointmentsView", "\320\224\320\220\320\242\320\220 \320\242\320\220 \320\247\320\220\320\241", nullptr));
        headerClient->setText(QCoreApplication::translate("AppointmentsView", "\320\232\320\233\320\206\320\204\320\235\320\242", nullptr));
        headerPet->setText(QCoreApplication::translate("AppointmentsView", "\320\232\320\233\320\230\320\247\320\232\320\220", nullptr));
        headerStatus->setText(QCoreApplication::translate("AppointmentsView", "\320\241\320\242\320\220\320\242\320\243\320\241", nullptr));
        emptyLabel->setText(QCoreApplication::translate("AppointmentsView", "\320\227\320\260\320\277\320\270\321\201\321\226\320\262 \320\267\320\260 \321\204\321\226\320\273\321\214\321\202\321\200\320\276\320\274 \320\275\320\265 \320\267\320\275\320\260\320\271\320\264\320\265\320\275\320\276", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AppointmentsView: public Ui_AppointmentsView {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_APPOINTMENTSVIEW_H
