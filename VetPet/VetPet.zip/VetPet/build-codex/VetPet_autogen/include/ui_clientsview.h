/********************************************************************************
** Form generated from reading UI file 'clientsview.ui'
**
** Created by: Qt User Interface Compiler version 6.11.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLIENTSVIEW_H
#define UI_CLIENTSVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ClientsView
{
public:
    QWidget *addOverlay;
    QVBoxLayout *overlayLayout;
    QSpacerItem *overlayTopSpacer;
    QFrame *addModalCard;
    QVBoxLayout *modalLayout;
    QLabel *addModalTitle;
    QLineEdit *addLastNameEdit;
    QLineEdit *addFirstNameEdit;
    QLineEdit *addPhoneEdit;
    QLineEdit *addEmailEdit;
    QLabel *errorLabel;
    QHBoxLayout *modalButtonsLayout;
    QPushButton *cancelAddBtn;
    QPushButton *saveAddBtn;
    QSpacerItem *overlayBottomSpacer;
    QVBoxLayout *mainLayout;
    QLabel *titleLabel;
    QHBoxLayout *searchLayout;
    QLineEdit *searchEdit;
    QPushButton *sortBtn;
    QPushButton *newBtn;
    QHBoxLayout *headerLayout;
    QLabel *headerPhone;
    QSpacerItem *headerSpacer1;
    QLabel *headerName;
    QSpacerItem *headerSpacer2;
    QSpacerItem *headerSpacer3;
    QTableWidget *clientsTable;

    void setupUi(QWidget *ClientsView)
    {
        if (ClientsView->objectName().isEmpty())
            ClientsView->setObjectName("ClientsView");
        ClientsView->resize(900, 600);
        addOverlay = new QWidget(ClientsView);
        addOverlay->setObjectName("addOverlay");
        addOverlay->setVisible(false);
        overlayLayout = new QVBoxLayout(addOverlay);
        overlayLayout->setObjectName("overlayLayout");
        overlayLayout->setContentsMargins(0, 0, 0, 0);
        overlayTopSpacer = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        overlayLayout->addItem(overlayTopSpacer);

        addModalCard = new QFrame(addOverlay);
        addModalCard->setObjectName("addModalCard");
        addModalCard->setMinimumSize(QSize(420, 0));
        addModalCard->setMaximumSize(QSize(420, 16777215));
        addModalCard->setFrameShape(QFrame::StyledPanel);
        modalLayout = new QVBoxLayout(addModalCard);
        modalLayout->setSpacing(14);
        modalLayout->setObjectName("modalLayout");
        modalLayout->setContentsMargins(28, 28, 28, 28);
        addModalTitle = new QLabel(addModalCard);
        addModalTitle->setObjectName("addModalTitle");

        modalLayout->addWidget(addModalTitle, 0, Qt::AlignHCenter);

        addLastNameEdit = new QLineEdit(addModalCard);
        addLastNameEdit->setObjectName("addLastNameEdit");

        modalLayout->addWidget(addLastNameEdit);

        addFirstNameEdit = new QLineEdit(addModalCard);
        addFirstNameEdit->setObjectName("addFirstNameEdit");

        modalLayout->addWidget(addFirstNameEdit);

        addPhoneEdit = new QLineEdit(addModalCard);
        addPhoneEdit->setObjectName("addPhoneEdit");

        modalLayout->addWidget(addPhoneEdit);

        addEmailEdit = new QLineEdit(addModalCard);
        addEmailEdit->setObjectName("addEmailEdit");

        modalLayout->addWidget(addEmailEdit);

        errorLabel = new QLabel(addModalCard);
        errorLabel->setObjectName("errorLabel");
        errorLabel->setVisible(false);

        modalLayout->addWidget(errorLabel, 0, Qt::AlignHCenter);

        modalButtonsLayout = new QHBoxLayout();
        modalButtonsLayout->setSpacing(10);
        modalButtonsLayout->setObjectName("modalButtonsLayout");
        modalButtonsLayout->setContentsMargins(-1, 8, -1, -1);
        cancelAddBtn = new QPushButton(addModalCard);
        cancelAddBtn->setObjectName("cancelAddBtn");

        modalButtonsLayout->addWidget(cancelAddBtn);

        saveAddBtn = new QPushButton(addModalCard);
        saveAddBtn->setObjectName("saveAddBtn");

        modalButtonsLayout->addWidget(saveAddBtn);


        modalLayout->addLayout(modalButtonsLayout);


        overlayLayout->addWidget(addModalCard, 0, Qt::AlignHCenter);

        overlayBottomSpacer = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        overlayLayout->addItem(overlayBottomSpacer);

        mainLayout = new QVBoxLayout(ClientsView);
        mainLayout->setSpacing(0);
        mainLayout->setObjectName("mainLayout");
        mainLayout->setContentsMargins(30, 25, 30, 25);
        titleLabel = new QLabel(ClientsView);
        titleLabel->setObjectName("titleLabel");

        mainLayout->addWidget(titleLabel);

        searchLayout = new QHBoxLayout();
        searchLayout->setSpacing(10);
        searchLayout->setObjectName("searchLayout");
        searchLayout->setContentsMargins(-1, -1, -1, 20);
        searchEdit = new QLineEdit(ClientsView);
        searchEdit->setObjectName("searchEdit");
        searchEdit->setMinimumSize(QSize(0, 42));

        searchLayout->addWidget(searchEdit);

        sortBtn = new QPushButton(ClientsView);
        sortBtn->setObjectName("sortBtn");
        sortBtn->setMinimumSize(QSize(60, 42));
        sortBtn->setMaximumSize(QSize(60, 42));

        searchLayout->addWidget(sortBtn);

        newBtn = new QPushButton(ClientsView);
        newBtn->setObjectName("newBtn");
        newBtn->setMinimumSize(QSize(100, 42));
        newBtn->setMaximumSize(QSize(100, 42));
        QFont font;
        font.setBold(false);
        newBtn->setFont(font);

        searchLayout->addWidget(newBtn);


        mainLayout->addLayout(searchLayout);

        headerLayout = new QHBoxLayout();
        headerLayout->setObjectName("headerLayout");
        headerLayout->setContentsMargins(10, -1, 10, 8);
        headerPhone = new QLabel(ClientsView);
        headerPhone->setObjectName("headerPhone");
        headerPhone->setMinimumSize(QSize(150, 0));
        headerPhone->setMaximumSize(QSize(150, 16777215));
        headerPhone->setAlignment(Qt::AlignCenter);

        headerLayout->addWidget(headerPhone);

        headerSpacer1 = new QSpacerItem(20, 20, QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Minimum);

        headerLayout->addItem(headerSpacer1);

        headerName = new QLabel(ClientsView);
        headerName->setObjectName("headerName");
        headerName->setMinimumSize(QSize(200, 0));
        headerName->setAlignment(Qt::AlignCenter);

        headerLayout->addWidget(headerName);

        headerSpacer2 = new QSpacerItem(40, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        headerLayout->addItem(headerSpacer2);

        headerSpacer3 = new QSpacerItem(60, 20, QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Minimum);

        headerLayout->addItem(headerSpacer3);


        mainLayout->addLayout(headerLayout);

        clientsTable = new QTableWidget(ClientsView);
        if (clientsTable->columnCount() < 3)
            clientsTable->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        clientsTable->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        clientsTable->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        clientsTable->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        clientsTable->setObjectName("clientsTable");
        clientsTable->setFocusPolicy(Qt::NoFocus);
        clientsTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
        clientsTable->setTabKeyNavigation(false);
        clientsTable->setShowGrid(false);
        clientsTable->setSelectionMode(QAbstractItemView::SingleSelection);
        clientsTable->setSelectionBehavior(QAbstractItemView::SelectRows);
        clientsTable->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
        clientsTable->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        clientsTable->horizontalHeader()->setVisible(false);
        clientsTable->verticalHeader()->setVisible(false);

        mainLayout->addWidget(clientsTable);


        retranslateUi(ClientsView);

        QMetaObject::connectSlotsByName(ClientsView);
    } // setupUi

    void retranslateUi(QWidget *ClientsView)
    {
        ClientsView->setStyleSheet(QCoreApplication::translate("ClientsView", "\n"
"    QWidget#ClientsView { background-color: transparent; }\n"
"    QLabel#titleLabel { color: #FFFFFF; font-size: 26px; font-weight: bold; }\n"
"    QLabel.headerLabel { color: #757575; font-size: 12px; font-weight: 600; }\n"
"    QLineEdit#searchEdit {\n"
"     background-color: #3A3A3A; color: #FFFFFF; border: none;\n"
"     border-radius: 10px; padding: 0 14px; font-size: 15px;\n"
"    }\n"
"    QLineEdit#searchEdit::placeholder { color: #767676; }\n"
"    QPushButton#sortBtn, QPushButton#newBtn {\n"
"     background-color: #3A3A3A; color: #FFFFFF; border: none;\n"
"     border-radius: 10px; font-weight: bold; font-size: 14px;\n"
"    }\n"
"    QPushButton#sortBtn:hover, QPushButton#newBtn:hover { background-color: #505050; }\n"
"    QTableWidget#clientsTable {\n"
"     background-color: transparent; color: #FFFFFF; border: none;\n"
"     gridline-color: transparent; outline: none;\n"
"    }\n"
"    QTableWidget#clientsTable::item { border-bottom: 1px solid rgba(255,255,255,13); padding: 0 10px; }\n"
""
                        "    QTableWidget#clientsTable::item:hover { background-color: #333333; }\n"
"    QTableWidget#clientsTable::item:selected { background-color: #333333; color: #FFFFFF; }\n"
"    QHeaderView::section {\n"
"     background-color: transparent; color: #757575; border: none;\n"
"     font-size: 12px; font-weight: 600; padding: 0 10px 8px 10px;\n"
"    }\n"
"    QWidget#addOverlay { background-color: rgba(0, 0, 0, 165); }\n"
"    QFrame#addModalCard {\n"
"     background-color: #2B2B2B; border: 1px solid #4A4A4A; border-radius: 14px;\n"
"    }\n"
"    QLabel#addModalTitle { color: #FFFFFF; font-size: 20px; font-weight: bold; }\n"
"    QLineEdit.modalField {\n"
"     background-color: #3A3A3A; color: #FFFFFF; border: none;\n"
"     border-radius: 10px; padding: 0 14px; font-size: 15px; min-height: 42px;\n"
"    }\n"
"    QLineEdit.modalField::placeholder { color: #767676; }\n"
"    QLabel#errorLabel { color: #FF6B6B; font-size: 13px; }\n"
"    QPushButton#cancelAddBtn {\n"
"     background-color: #3A3A3A; color: #AAAA"
                        "AA; border: none;\n"
"     border-radius: 10px; min-height: 42px; font-size: 15px;\n"
"    }\n"
"    QPushButton#saveAddBtn {\n"
"     background-color: #3A3A3A; color: #FFFFFF; border: 1.5px solid #4A7C59;\n"
"     border-radius: 10px; min-height: 42px; font-size: 15px; font-weight: 600;\n"
"    }\n"
"    QPushButton#cancelAddBtn:hover, QPushButton#saveAddBtn:hover { background-color: #505050; }\n"
"   ", nullptr));
        addModalTitle->setText(QCoreApplication::translate("ClientsView", "\320\235\320\276\320\262\320\270\320\271 \320\272\320\273\321\226\321\224\320\275\321\202", nullptr));
        addLastNameEdit->setProperty("class", QVariant(QCoreApplication::translate("ClientsView", "modalField", nullptr)));
        addLastNameEdit->setPlaceholderText(QCoreApplication::translate("ClientsView", "\320\237\321\200\321\226\320\267\320\262\320\270\321\211\320\265 *", nullptr));
        addFirstNameEdit->setProperty("class", QVariant(QCoreApplication::translate("ClientsView", "modalField", nullptr)));
        addFirstNameEdit->setPlaceholderText(QCoreApplication::translate("ClientsView", "\320\206\320\274'\321\217 *", nullptr));
        addPhoneEdit->setProperty("class", QVariant(QCoreApplication::translate("ClientsView", "modalField", nullptr)));
        addPhoneEdit->setPlaceholderText(QCoreApplication::translate("ClientsView", "\320\235\320\276\320\274\320\265\321\200 \321\202\320\265\320\273\320\265\321\204\320\276\320\275\321\203 *", nullptr));
        addEmailEdit->setProperty("class", QVariant(QCoreApplication::translate("ClientsView", "modalField", nullptr)));
        addEmailEdit->setPlaceholderText(QCoreApplication::translate("ClientsView", "Email (\320\275\320\265\320\276\320\261\320\276\320\262'\321\217\320\267\320\272\320\276\320\262\320\276)", nullptr));
        errorLabel->setText(QString());
        cancelAddBtn->setText(QCoreApplication::translate("ClientsView", "\320\241\320\272\320\260\321\201\321\203\320\262\320\260\321\202\320\270", nullptr));
        saveAddBtn->setText(QCoreApplication::translate("ClientsView", "\320\227\320\261\320\265\321\200\320\265\320\263\321\202\320\270", nullptr));
        titleLabel->setText(QCoreApplication::translate("ClientsView", "\320\232\320\273\321\226\321\224\320\275\321\202\320\270", nullptr));
        searchEdit->setPlaceholderText(QCoreApplication::translate("ClientsView", "\342\214\225 \320\237\320\276\321\210\321\203\320\272 (\321\202\320\265\320\273\320\265\321\204\320\276\320\275, \321\226\320\274'\321\217, \320\277\321\200\321\226\320\267\320\262\320\270\321\211\320\265, \320\272\320\273\320\270\321\207\320\272\320\260)", nullptr));
        sortBtn->setText(QCoreApplication::translate("ClientsView", "\320\220 \342\206\222 \320\257", nullptr));
        newBtn->setText(QCoreApplication::translate("ClientsView", "+ \320\235\320\276\320\262\320\270\320\271", nullptr));
        headerPhone->setText(QCoreApplication::translate("ClientsView", "\320\242\320\225\320\233\320\225\320\244\320\236\320\235", nullptr));
        headerPhone->setProperty("class", QVariant(QCoreApplication::translate("ClientsView", "headerLabel", nullptr)));
        headerName->setText(QCoreApplication::translate("ClientsView", "\320\237\320\240\320\206\320\227\320\222\320\230\320\251\320\225 \320\242\320\220 \320\206\320\234'\320\257", nullptr));
        headerName->setProperty("class", QVariant(QCoreApplication::translate("ClientsView", "headerLabel", nullptr)));
    } // retranslateUi

};

namespace Ui {
    class ClientsView: public Ui_ClientsView {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLIENTSVIEW_H
