/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.11.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout;
    QWidget *sidebarWidget;
    QVBoxLayout *verticalLayout_2;
    QLabel *logoLabel;
    QPushButton *navClientsBtn;
    QPushButton *navRecordsBtn;
    QPushButton *navStaffBtn;
    QPushButton *navProvidersBtn;
    QPushButton *navStockBtn;
    QSpacerItem *verticalSpacer;
    QWidget *mainWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *topBarLayout;
    QLabel *topLabel;
    QSpacerItem *horizontalSpacer;
    QPushButton *quickRecordBtn;
    QStackedWidget *stackedWidget;
    QWidget *pageClients;
    QVBoxLayout *verticalLayout_3;
    QWidget *pageRecords;
    QVBoxLayout *verticalLayout_4;
    QWidget *pageStaff;
    QVBoxLayout *verticalLayout_5;
    QWidget *pageProviders;
    QVBoxLayout *verticalLayout_6;
    QWidget *pageStock;
    QVBoxLayout *verticalLayout_7;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1200, 800);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        horizontalLayout = new QHBoxLayout(centralwidget);
        horizontalLayout->setSpacing(15);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(15, 15, 15, 15);
        sidebarWidget = new QWidget(centralwidget);
        sidebarWidget->setObjectName("sidebarWidget");
        sidebarWidget->setMinimumSize(QSize(220, 0));
        sidebarWidget->setMaximumSize(QSize(220, 16777215));
        verticalLayout_2 = new QVBoxLayout(sidebarWidget);
        verticalLayout_2->setSpacing(10);
        verticalLayout_2->setObjectName("verticalLayout_2");
        logoLabel = new QLabel(sidebarWidget);
        logoLabel->setObjectName("logoLabel");
        logoLabel->setAlignment(Qt::AlignCenter);
        logoLabel->setMargin(20);

        verticalLayout_2->addWidget(logoLabel);

        navClientsBtn = new QPushButton(sidebarWidget);
        navClientsBtn->setObjectName("navClientsBtn");
        navClientsBtn->setCheckable(true);
        navClientsBtn->setChecked(true);
        navClientsBtn->setAutoExclusive(true);

        verticalLayout_2->addWidget(navClientsBtn);

        navRecordsBtn = new QPushButton(sidebarWidget);
        navRecordsBtn->setObjectName("navRecordsBtn");
        navRecordsBtn->setCheckable(true);
        navRecordsBtn->setAutoExclusive(true);

        verticalLayout_2->addWidget(navRecordsBtn);

        navStaffBtn = new QPushButton(sidebarWidget);
        navStaffBtn->setObjectName("navStaffBtn");
        navStaffBtn->setCheckable(true);
        navStaffBtn->setAutoExclusive(true);

        verticalLayout_2->addWidget(navStaffBtn);

        navProvidersBtn = new QPushButton(sidebarWidget);
        navProvidersBtn->setObjectName("navProvidersBtn");
        navProvidersBtn->setCheckable(true);
        navProvidersBtn->setAutoExclusive(true);

        verticalLayout_2->addWidget(navProvidersBtn);

        navStockBtn = new QPushButton(sidebarWidget);
        navStockBtn->setObjectName("navStockBtn");
        navStockBtn->setCheckable(true);
        navStockBtn->setAutoExclusive(true);

        verticalLayout_2->addWidget(navStockBtn);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);


        horizontalLayout->addWidget(sidebarWidget);

        mainWidget = new QWidget(centralwidget);
        mainWidget->setObjectName("mainWidget");
        verticalLayout = new QVBoxLayout(mainWidget);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(30, 20, 30, 20);
        topBarLayout = new QHBoxLayout();
        topBarLayout->setObjectName("topBarLayout");
        topLabel = new QLabel(mainWidget);
        topLabel->setObjectName("topLabel");

        topBarLayout->addWidget(topLabel);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        topBarLayout->addItem(horizontalSpacer);

        quickRecordBtn = new QPushButton(mainWidget);
        quickRecordBtn->setObjectName("quickRecordBtn");
        quickRecordBtn->setMinimumSize(QSize(150, 35));

        topBarLayout->addWidget(quickRecordBtn);


        verticalLayout->addLayout(topBarLayout);

        stackedWidget = new QStackedWidget(mainWidget);
        stackedWidget->setObjectName("stackedWidget");
        pageClients = new QWidget();
        pageClients->setObjectName("pageClients");
        verticalLayout_3 = new QVBoxLayout(pageClients);
        verticalLayout_3->setObjectName("verticalLayout_3");
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        stackedWidget->addWidget(pageClients);
        pageRecords = new QWidget();
        pageRecords->setObjectName("pageRecords");
        verticalLayout_4 = new QVBoxLayout(pageRecords);
        verticalLayout_4->setObjectName("verticalLayout_4");
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        stackedWidget->addWidget(pageRecords);
        pageStaff = new QWidget();
        pageStaff->setObjectName("pageStaff");
        verticalLayout_5 = new QVBoxLayout(pageStaff);
        verticalLayout_5->setObjectName("verticalLayout_5");
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        stackedWidget->addWidget(pageStaff);
        pageProviders = new QWidget();
        pageProviders->setObjectName("pageProviders");
        verticalLayout_6 = new QVBoxLayout(pageProviders);
        verticalLayout_6->setObjectName("verticalLayout_6");
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        stackedWidget->addWidget(pageProviders);
        pageStock = new QWidget();
        pageStock->setObjectName("pageStock");
        verticalLayout_7 = new QVBoxLayout(pageStock);
        verticalLayout_7->setObjectName("verticalLayout_7");
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        stackedWidget->addWidget(pageStock);

        verticalLayout->addWidget(stackedWidget);


        horizontalLayout->addWidget(mainWidget);

        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "VetPet", nullptr));
        MainWindow->setStyleSheet(QCoreApplication::translate("MainWindow", "\n"
"    QMainWindow { background-color: #1E1E1E; }\n"
"    QWidget#sidebarWidget, QWidget#mainWidget { background-color: #2D2D30; border-radius: 10px; }\n"
"    QLabel#logoLabel { color: #FFFFFF; font-size: 24px; font-weight: bold; }\n"
"    QLabel { color: #FFFFFF; }\n"
"    QPushButton { background-color: transparent; color: #CCCCCC; text-align: left; padding: 10px; border-radius: 5px; font-size: 14px; }\n"
"    QPushButton:hover { background-color: #3E3E42; color: #FFFFFF; }\n"
"    QPushButton:checked { background-color: #3F3F46; color: #FFFFFF; font-weight: bold; }\n"
"    QPushButton#quickRecordBtn, QPushButton#newBtn { background-color: #3E3E42; color: #FFFFFF; text-align: center; border: 1px solid #555555; }\n"
"    QLineEdit { background-color: #1E1E1E; color: #FFFFFF; border: none; padding: 10px; border-radius: 5px; }\n"
"    QTableWidget { background-color: transparent; color: #FFFFFF; border: none; gridline-color: #3E3E42; }\n"
"    QHeaderView::section { background-color: #2D2D30; color: #888888;"
                        " border: none; text-align: left; padding: 5px; }\n"
"    QTableWidget { background-color: transparent; border: none; }\n"
"    QTableWidget::item { border-bottom: 1px solid #3E3E42; padding-left: 20px; }\n"
"    QTableWidget::item:hover { background-color: #3E3E42; }\n"
"    QTableWidget::item:selected { background-color: #3F3F46; color: #FFFFFF; }\n"
"   ", nullptr));
        logoLabel->setText(QCoreApplication::translate("MainWindow", "VetPet", nullptr));
        navClientsBtn->setText(QCoreApplication::translate("MainWindow", "\360\237\220\276 \320\232\320\273\321\226\321\224\320\275\321\202\320\270", nullptr));
        navRecordsBtn->setText(QCoreApplication::translate("MainWindow", "\360\237\223\205 \320\227\320\260\320\277\320\270\321\201\320\270", nullptr));
        navStaffBtn->setText(QCoreApplication::translate("MainWindow", "\360\237\221\244 \320\237\321\200\320\260\321\206\321\226\320\262\320\275\320\270\320\272\320\270", nullptr));
        navProvidersBtn->setText(QCoreApplication::translate("MainWindow", "\360\237\217\242 \320\237\321\200\320\276\320\262\320\260\320\271\320\264\320\265\321\200\320\270", nullptr));
        navStockBtn->setText(QCoreApplication::translate("MainWindow", "\360\237\222\212 \320\241\320\272\320\273\320\260\320\264", nullptr));
        topLabel->setText(QCoreApplication::translate("MainWindow", "\320\240\320\276\320\261\320\276\321\207\320\260 \320\277\320\260\320\275\320\265\320\273\321\214", nullptr));
        topLabel->setStyleSheet(QCoreApplication::translate("MainWindow", "color: #888888;", nullptr));
        quickRecordBtn->setText(QCoreApplication::translate("MainWindow", "+ \320\250\320\262\320\270\320\264\320\272\320\270\320\271 \320\267\320\260\320\277\320\270\321\201", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
