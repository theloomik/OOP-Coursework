/********************************************************************************
** Form generated from reading UI file 'providersview.ui'
**
** Created by: Qt User Interface Compiler version 6.11.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PROVIDERSVIEW_H
#define UI_PROVIDERSVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ProvidersView
{
public:
    QWidget *addOverlay;
    QVBoxLayout *overlayLayout;
    QSpacerItem *overlayTopSpacer;
    QFrame *addModalCard;
    QVBoxLayout *modalLayout;
    QLabel *addModalTitle;
    QLineEdit *addNameEdit;
    QLineEdit *addPhoneEdit;
    QLineEdit *addContactEdit;
    QLineEdit *addEmailEdit;
    QLineEdit *addAddressEdit;
    QLabel *errorLabel;
    QHBoxLayout *modalButtonsLayout;
    QPushButton *cancelAddBtn;
    QPushButton *saveAddBtn;
    QSpacerItem *overlayBottomSpacer;
    QVBoxLayout *mainLayout;
    QLabel *titleLabel;
    QHBoxLayout *searchLayout;
    QLineEdit *searchEdit;
    QPushButton *sortBtn;
    QPushButton *newBtn;
    QHBoxLayout *headerLayout;
    QLabel *headerPhone;
    QSpacerItem *headerSpacer1;
    QLabel *headerName;
    QSpacerItem *headerSpacer2;
    QSpacerItem *headerSpacer3;
    QTableWidget *providersTable;

    void setupUi(QWidget *ProvidersView)
    {
        if (ProvidersView->objectName().isEmpty())
            ProvidersView->setObjectName("ProvidersView");
        addOverlay = new QWidget(ProvidersView);
        addOverlay->setObjectName("addOverlay");
        addOverlay->setVisible(false);
        overlayLayout = new QVBoxLayout(addOverlay);
        overlayLayout->setObjectName("overlayLayout");
        overlayLayout->setContentsMargins(0, 0, 0, 0);
        overlayTopSpacer = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        overlayLayout->addItem(overlayTopSpacer);

        addModalCard = new QFrame(addOverlay);
        addModalCard->setObjectName("addModalCard");
        addModalCard->setMinimumSize(QSize(420, 0));
        addModalCard->setMaximumSize(QSize(420, 16777215));
        modalLayout = new QVBoxLayout(addModalCard);
        modalLayout->setSpacing(14);
        modalLayout->setObjectName("modalLayout");
        modalLayout->setContentsMargins(28, 28, 28, 28);
        addModalTitle = new QLabel(addModalCard);
        addModalTitle->setObjectName("addModalTitle");

        modalLayout->addWidget(addModalTitle, 0, Qt::AlignHCenter);

        addNameEdit = new QLineEdit(addModalCard);
        addNameEdit->setObjectName("addNameEdit");

        modalLayout->addWidget(addNameEdit);

        addPhoneEdit = new QLineEdit(addModalCard);
        addPhoneEdit->setObjectName("addPhoneEdit");

        modalLayout->addWidget(addPhoneEdit);

        addContactEdit = new QLineEdit(addModalCard);
        addContactEdit->setObjectName("addContactEdit");

        modalLayout->addWidget(addContactEdit);

        addEmailEdit = new QLineEdit(addModalCard);
        addEmailEdit->setObjectName("addEmailEdit");

        modalLayout->addWidget(addEmailEdit);

        addAddressEdit = new QLineEdit(addModalCard);
        addAddressEdit->setObjectName("addAddressEdit");

        modalLayout->addWidget(addAddressEdit);

        errorLabel = new QLabel(addModalCard);
        errorLabel->setObjectName("errorLabel");
        errorLabel->setVisible(false);

        modalLayout->addWidget(errorLabel, 0, Qt::AlignHCenter);

        modalButtonsLayout = new QHBoxLayout();
        modalButtonsLayout->setSpacing(10);
        modalButtonsLayout->setObjectName("modalButtonsLayout");
        cancelAddBtn = new QPushButton(addModalCard);
        cancelAddBtn->setObjectName("cancelAddBtn");

        modalButtonsLayout->addWidget(cancelAddBtn);

        saveAddBtn = new QPushButton(addModalCard);
        saveAddBtn->setObjectName("saveAddBtn");

        modalButtonsLayout->addWidget(saveAddBtn);


        modalLayout->addLayout(modalButtonsLayout);


        overlayLayout->addWidget(addModalCard, 0, Qt::AlignHCenter);

        overlayBottomSpacer = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        overlayLayout->addItem(overlayBottomSpacer);

        mainLayout = new QVBoxLayout(ProvidersView);
        mainLayout->setObjectName("mainLayout");
        mainLayout->setContentsMargins(30, 25, 30, 25);
        titleLabel = new QLabel(ProvidersView);
        titleLabel->setObjectName("titleLabel");

        mainLayout->addWidget(titleLabel);

        searchLayout = new QHBoxLayout();
        searchLayout->setSpacing(10);
        searchLayout->setObjectName("searchLayout");
        searchLayout->setContentsMargins(-1, -1, -1, 20);
        searchEdit = new QLineEdit(ProvidersView);
        searchEdit->setObjectName("searchEdit");

        searchLayout->addWidget(searchEdit);

        sortBtn = new QPushButton(ProvidersView);
        sortBtn->setObjectName("sortBtn");
        sortBtn->setMinimumSize(QSize(60, 42));
        sortBtn->setMaximumSize(QSize(60, 42));

        searchLayout->addWidget(sortBtn);

        newBtn = new QPushButton(ProvidersView);
        newBtn->setObjectName("newBtn");
        newBtn->setMinimumSize(QSize(100, 42));
        newBtn->setMaximumSize(QSize(100, 42));

        searchLayout->addWidget(newBtn);


        mainLayout->addLayout(searchLayout);

        headerLayout = new QHBoxLayout();
        headerLayout->setObjectName("headerLayout");
        headerLayout->setContentsMargins(10, -1, 10, 8);
        headerPhone = new QLabel(ProvidersView);
        headerPhone->setObjectName("headerPhone");
        headerPhone->setMinimumSize(QSize(150, 0));
        headerPhone->setMaximumSize(QSize(150, 16777215));
        headerPhone->setAlignment(Qt::AlignCenter);

        headerLayout->addWidget(headerPhone);

        headerSpacer1 = new QSpacerItem(20, 20, QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Minimum);

        headerLayout->addItem(headerSpacer1);

        headerName = new QLabel(ProvidersView);
        headerName->setObjectName("headerName");
        headerName->setAlignment(Qt::AlignCenter);

        headerLayout->addWidget(headerName);

        headerSpacer2 = new QSpacerItem(40, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        headerLayout->addItem(headerSpacer2);

        headerSpacer3 = new QSpacerItem(60, 20, QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Minimum);

        headerLayout->addItem(headerSpacer3);


        mainLayout->addLayout(headerLayout);

        providersTable = new QTableWidget(ProvidersView);
        if (providersTable->columnCount() < 3)
            providersTable->setColumnCount(3);
        providersTable->setObjectName("providersTable");
        providersTable->setFocusPolicy(Qt::NoFocus);
        providersTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
        providersTable->setShowGrid(false);
        providersTable->setSelectionBehavior(QAbstractItemView::SelectRows);
        providersTable->horizontalHeader()->setVisible(false);
        providersTable->verticalHeader()->setVisible(false);

        mainLayout->addWidget(providersTable);


        retranslateUi(ProvidersView);

        QMetaObject::connectSlotsByName(ProvidersView);
    } // setupUi

    void retranslateUi(QWidget *ProvidersView)
    {
        ProvidersView->setStyleSheet(QCoreApplication::translate("ProvidersView", "\n"
"    QLabel#titleLabel { color: #FFFFFF; font-size: 26px; font-weight: bold; }\n"
"    QLabel.headerLabel { color: #757575; font-size: 12px; font-weight: 600; }\n"
"    QLineEdit#searchEdit { background-color: #3A3A3A; color: #FFFFFF; border: none; border-radius: 10px; padding: 0 14px; font-size: 15px; min-height: 42px; }\n"
"    QLineEdit#searchEdit::placeholder { color: #767676; }\n"
"    QPushButton#sortBtn, QPushButton#newBtn { background-color: #3A3A3A; color: #FFFFFF; border: none; border-radius: 10px; font-weight: bold; }\n"
"    QPushButton#sortBtn:hover, QPushButton#newBtn:hover { background-color: #505050; }\n"
"    QTableWidget#providersTable { background-color: transparent; color: #FFFFFF; border: none; outline: none; }\n"
"    QTableWidget#providersTable::item { border-bottom: 1px solid rgba(255,255,255,13); }\n"
"    QTableWidget#providersTable::item:hover { background-color: #333333; }\n"
"    QWidget#addOverlay { background-color: rgba(0, 0, 0, 165); }\n"
"    QFrame#addModalCard { backgrou"
                        "nd-color: #2B2B2B; border: 1px solid #4A4A4A; border-radius: 14px; }\n"
"    QLineEdit.modalField { background-color: #3A3A3A; color: #FFFFFF; border: none; border-radius: 10px; padding: 0 14px; min-height: 42px; }\n"
"    QLabel#errorLabel { color: #FF6B6B; font-size: 13px; }\n"
"    QPushButton#cancelAddBtn { background-color: #3A3A3A; color: #AAAAAA; border: none; border-radius: 10px; min-height: 42px; }\n"
"    QPushButton#saveAddBtn { background-color: #3A3A3A; color: #FFFFFF; border: 1.5px solid #4A7C59; border-radius: 10px; min-height: 42px; font-weight: 600; }\n"
"   ", nullptr));
        addModalTitle->setText(QCoreApplication::translate("ProvidersView", "\320\235\320\276\320\262\320\270\320\271 \320\277\321\200\320\276\320\262\320\260\320\271\320\264\320\265\321\200", nullptr));
        addModalTitle->setStyleSheet(QCoreApplication::translate("ProvidersView", "color: white; font-size: 20px; font-weight: bold;", nullptr));
        addNameEdit->setPlaceholderText(QCoreApplication::translate("ProvidersView", "\320\235\320\260\320\267\320\262\320\260 *", nullptr));
        addPhoneEdit->setPlaceholderText(QCoreApplication::translate("ProvidersView", "\320\235\320\276\320\274\320\265\321\200 \321\202\320\265\320\273\320\265\321\204\320\276\320\275\321\203 *", nullptr));
        addContactEdit->setPlaceholderText(QCoreApplication::translate("ProvidersView", "\320\232\320\276\320\275\321\202\320\260\320\272\321\202\320\275\320\260 \320\276\321\201\320\276\320\261\320\260", nullptr));
        addEmailEdit->setPlaceholderText(QCoreApplication::translate("ProvidersView", "Email", nullptr));
        addAddressEdit->setPlaceholderText(QCoreApplication::translate("ProvidersView", "\320\220\320\264\321\200\320\265\321\201\320\260", nullptr));
        cancelAddBtn->setText(QCoreApplication::translate("ProvidersView", "\320\241\320\272\320\260\321\201\321\203\320\262\320\260\321\202\320\270", nullptr));
        saveAddBtn->setText(QCoreApplication::translate("ProvidersView", "\320\227\320\261\320\265\321\200\320\265\320\263\321\202\320\270", nullptr));
        titleLabel->setText(QCoreApplication::translate("ProvidersView", "\320\237\321\200\320\276\320\262\320\260\320\271\320\264\320\265\321\200\320\270", nullptr));
        searchEdit->setPlaceholderText(QCoreApplication::translate("ProvidersView", "\320\237\320\276\321\210\321\203\320\272 (\320\275\320\260\320\267\320\262\320\260, \321\202\320\265\320\273\320\265\321\204\320\276\320\275, \320\272\320\276\320\275\321\202\320\260\320\272\321\202)", nullptr));
        sortBtn->setText(QCoreApplication::translate("ProvidersView", "\320\220 \342\206\222 \320\257", nullptr));
        newBtn->setText(QCoreApplication::translate("ProvidersView", "+ \320\235\320\276\320\262\320\270\320\271", nullptr));
        headerPhone->setText(QCoreApplication::translate("ProvidersView", "\320\242\320\225\320\233\320\225\320\244\320\236\320\235", nullptr));
        headerName->setText(QCoreApplication::translate("ProvidersView", "\320\235\320\220\320\227\320\222\320\220 / \320\237\320\240\320\225\320\224\320\241\320\242\320\220\320\222\320\235\320\230\320\232", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ProvidersView: public Ui_ProvidersView {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PROVIDERSVIEW_H
