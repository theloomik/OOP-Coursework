/********************************************************************************
** Form generated from reading UI file 'staffview.ui'
**
** Created by: Qt User Interface Compiler version 6.11.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STAFFVIEW_H
#define UI_STAFFVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_StaffView
{
public:
    QWidget *addOverlay;
    QVBoxLayout *overlayLayout;
    QSpacerItem *overlayTopSpacer;
    QFrame *addModalCard;
    QVBoxLayout *modalLayout;
    QLabel *addModalTitle;
    QLineEdit *addLastNameEdit;
    QLineEdit *addFirstNameEdit;
    QLineEdit *addPhoneEdit;
    QLabel *positionHeader;
    QHBoxLayout *positionRowLayout;
    QComboBox *positionCombo;
    QPushButton *addPositionBtn;
    QFrame *positionPanel;
    QVBoxLayout *positionPanelLayout;
    QLabel *newPositionTitle;
    QLineEdit *newPositionNameEdit;
    QLineEdit *newPositionSalaryEdit;
    QLabel *positionErrorLabel;
    QHBoxLayout *positionButtonsLayout;
    QPushButton *cancelPositionBtn;
    QPushButton *savePositionBtn;
    QLabel *workDaysHeader;
    QHBoxLayout *workDaysLayout;
    QPushButton *dayMonBtn;
    QPushButton *dayTueBtn;
    QPushButton *dayWedBtn;
    QPushButton *dayThuBtn;
    QPushButton *dayFriBtn;
    QPushButton *daySatBtn;
    QPushButton *daySunBtn;
    QLabel *hoursHeader;
    QHBoxLayout *hoursLayout;
    QVBoxLayout *startTimeLayout;
    QLabel *startLabel;
    QLineEdit *startTimeEdit;
    QLabel *hoursDash;
    QVBoxLayout *endTimeLayout;
    QLabel *endLabel;
    QLineEdit *endTimeEdit;
    QLabel *errorLabel;
    QHBoxLayout *modalButtonsLayout;
    QPushButton *cancelAddBtn;
    QPushButton *saveAddBtn;
    QSpacerItem *overlayBottomSpacer;
    QVBoxLayout *mainLayout;
    QLabel *titleLabel;
    QHBoxLayout *searchLayout;
    QLineEdit *searchEdit;
    QPushButton *sortBtn;
    QPushButton *newBtn;
    QHBoxLayout *headerLayout;
    QLabel *headerPhone;
    QSpacerItem *headerSpacer1;
    QLabel *headerName;
    QSpacerItem *headerSpacer2;
    QSpacerItem *headerSpacer3;
    QTableWidget *staffTable;

    void setupUi(QWidget *StaffView)
    {
        if (StaffView->objectName().isEmpty())
            StaffView->setObjectName("StaffView");
        addOverlay = new QWidget(StaffView);
        addOverlay->setObjectName("addOverlay");
        addOverlay->setVisible(false);
        overlayLayout = new QVBoxLayout(addOverlay);
        overlayLayout->setObjectName("overlayLayout");
        overlayLayout->setContentsMargins(0, 0, 0, 0);
        overlayTopSpacer = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        overlayLayout->addItem(overlayTopSpacer);

        addModalCard = new QFrame(addOverlay);
        addModalCard->setObjectName("addModalCard");
        addModalCard->setMinimumSize(QSize(460, 0));
        addModalCard->setMaximumSize(QSize(460, 16777215));
        modalLayout = new QVBoxLayout(addModalCard);
        modalLayout->setSpacing(14);
        modalLayout->setObjectName("modalLayout");
        modalLayout->setContentsMargins(28, 28, 28, 28);
        addModalTitle = new QLabel(addModalCard);
        addModalTitle->setObjectName("addModalTitle");

        modalLayout->addWidget(addModalTitle, 0, Qt::AlignHCenter);

        addLastNameEdit = new QLineEdit(addModalCard);
        addLastNameEdit->setObjectName("addLastNameEdit");

        modalLayout->addWidget(addLastNameEdit);

        addFirstNameEdit = new QLineEdit(addModalCard);
        addFirstNameEdit->setObjectName("addFirstNameEdit");

        modalLayout->addWidget(addFirstNameEdit);

        addPhoneEdit = new QLineEdit(addModalCard);
        addPhoneEdit->setObjectName("addPhoneEdit");

        modalLayout->addWidget(addPhoneEdit);

        positionHeader = new QLabel(addModalCard);
        positionHeader->setObjectName("positionHeader");

        modalLayout->addWidget(positionHeader);

        positionRowLayout = new QHBoxLayout();
        positionRowLayout->setSpacing(8);
        positionRowLayout->setObjectName("positionRowLayout");
        positionCombo = new QComboBox(addModalCard);
        positionCombo->setObjectName("positionCombo");

        positionRowLayout->addWidget(positionCombo);

        addPositionBtn = new QPushButton(addModalCard);
        addPositionBtn->setObjectName("addPositionBtn");
        addPositionBtn->setMinimumSize(QSize(42, 42));
        addPositionBtn->setMaximumSize(QSize(42, 42));

        positionRowLayout->addWidget(addPositionBtn);


        modalLayout->addLayout(positionRowLayout);

        positionPanel = new QFrame(addModalCard);
        positionPanel->setObjectName("positionPanel");
        positionPanel->setVisible(false);
        positionPanelLayout = new QVBoxLayout(positionPanel);
        positionPanelLayout->setSpacing(10);
        positionPanelLayout->setObjectName("positionPanelLayout");
        positionPanelLayout->setContentsMargins(14, 14, 14, 14);
        newPositionTitle = new QLabel(positionPanel);
        newPositionTitle->setObjectName("newPositionTitle");

        positionPanelLayout->addWidget(newPositionTitle);

        newPositionNameEdit = new QLineEdit(positionPanel);
        newPositionNameEdit->setObjectName("newPositionNameEdit");

        positionPanelLayout->addWidget(newPositionNameEdit);

        newPositionSalaryEdit = new QLineEdit(positionPanel);
        newPositionSalaryEdit->setObjectName("newPositionSalaryEdit");

        positionPanelLayout->addWidget(newPositionSalaryEdit);

        positionErrorLabel = new QLabel(positionPanel);
        positionErrorLabel->setObjectName("positionErrorLabel");
        positionErrorLabel->setVisible(false);

        positionPanelLayout->addWidget(positionErrorLabel);

        positionButtonsLayout = new QHBoxLayout();
        positionButtonsLayout->setSpacing(8);
        positionButtonsLayout->setObjectName("positionButtonsLayout");
        cancelPositionBtn = new QPushButton(positionPanel);
        cancelPositionBtn->setObjectName("cancelPositionBtn");

        positionButtonsLayout->addWidget(cancelPositionBtn);

        savePositionBtn = new QPushButton(positionPanel);
        savePositionBtn->setObjectName("savePositionBtn");

        positionButtonsLayout->addWidget(savePositionBtn);


        positionPanelLayout->addLayout(positionButtonsLayout);


        modalLayout->addWidget(positionPanel);

        workDaysHeader = new QLabel(addModalCard);
        workDaysHeader->setObjectName("workDaysHeader");

        modalLayout->addWidget(workDaysHeader);

        workDaysLayout = new QHBoxLayout();
        workDaysLayout->setObjectName("workDaysLayout");
        dayMonBtn = new QPushButton(addModalCard);
        dayMonBtn->setObjectName("dayMonBtn");
        dayMonBtn->setCheckable(true);
        dayMonBtn->setChecked(true);

        workDaysLayout->addWidget(dayMonBtn);

        dayTueBtn = new QPushButton(addModalCard);
        dayTueBtn->setObjectName("dayTueBtn");
        dayTueBtn->setCheckable(true);
        dayTueBtn->setChecked(true);

        workDaysLayout->addWidget(dayTueBtn);

        dayWedBtn = new QPushButton(addModalCard);
        dayWedBtn->setObjectName("dayWedBtn");
        dayWedBtn->setCheckable(true);
        dayWedBtn->setChecked(true);

        workDaysLayout->addWidget(dayWedBtn);

        dayThuBtn = new QPushButton(addModalCard);
        dayThuBtn->setObjectName("dayThuBtn");
        dayThuBtn->setCheckable(true);
        dayThuBtn->setChecked(true);

        workDaysLayout->addWidget(dayThuBtn);

        dayFriBtn = new QPushButton(addModalCard);
        dayFriBtn->setObjectName("dayFriBtn");
        dayFriBtn->setCheckable(true);
        dayFriBtn->setChecked(true);

        workDaysLayout->addWidget(dayFriBtn);

        daySatBtn = new QPushButton(addModalCard);
        daySatBtn->setObjectName("daySatBtn");
        daySatBtn->setCheckable(true);

        workDaysLayout->addWidget(daySatBtn);

        daySunBtn = new QPushButton(addModalCard);
        daySunBtn->setObjectName("daySunBtn");
        daySunBtn->setCheckable(true);

        workDaysLayout->addWidget(daySunBtn);


        modalLayout->addLayout(workDaysLayout);

        hoursHeader = new QLabel(addModalCard);
        hoursHeader->setObjectName("hoursHeader");

        modalLayout->addWidget(hoursHeader);

        hoursLayout = new QHBoxLayout();
        hoursLayout->setSpacing(16);
        hoursLayout->setObjectName("hoursLayout");
        startTimeLayout = new QVBoxLayout();
        startTimeLayout->setObjectName("startTimeLayout");
        startLabel = new QLabel(addModalCard);
        startLabel->setObjectName("startLabel");

        startTimeLayout->addWidget(startLabel);

        startTimeEdit = new QLineEdit(addModalCard);
        startTimeEdit->setObjectName("startTimeEdit");
        startTimeEdit->setAlignment(Qt::AlignCenter);

        startTimeLayout->addWidget(startTimeEdit);


        hoursLayout->addLayout(startTimeLayout);

        hoursDash = new QLabel(addModalCard);
        hoursDash->setObjectName("hoursDash");

        hoursLayout->addWidget(hoursDash);

        endTimeLayout = new QVBoxLayout();
        endTimeLayout->setObjectName("endTimeLayout");
        endLabel = new QLabel(addModalCard);
        endLabel->setObjectName("endLabel");

        endTimeLayout->addWidget(endLabel);

        endTimeEdit = new QLineEdit(addModalCard);
        endTimeEdit->setObjectName("endTimeEdit");
        endTimeEdit->setAlignment(Qt::AlignCenter);

        endTimeLayout->addWidget(endTimeEdit);


        hoursLayout->addLayout(endTimeLayout);


        modalLayout->addLayout(hoursLayout);

        errorLabel = new QLabel(addModalCard);
        errorLabel->setObjectName("errorLabel");
        errorLabel->setVisible(false);

        modalLayout->addWidget(errorLabel, 0, Qt::AlignHCenter);

        modalButtonsLayout = new QHBoxLayout();
        modalButtonsLayout->setSpacing(10);
        modalButtonsLayout->setObjectName("modalButtonsLayout");
        cancelAddBtn = new QPushButton(addModalCard);
        cancelAddBtn->setObjectName("cancelAddBtn");

        modalButtonsLayout->addWidget(cancelAddBtn);

        saveAddBtn = new QPushButton(addModalCard);
        saveAddBtn->setObjectName("saveAddBtn");

        modalButtonsLayout->addWidget(saveAddBtn);


        modalLayout->addLayout(modalButtonsLayout);


        overlayLayout->addWidget(addModalCard, 0, Qt::AlignHCenter);

        overlayBottomSpacer = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        overlayLayout->addItem(overlayBottomSpacer);

        mainLayout = new QVBoxLayout(StaffView);
        mainLayout->setObjectName("mainLayout");
        mainLayout->setContentsMargins(30, 25, 30, 25);
        titleLabel = new QLabel(StaffView);
        titleLabel->setObjectName("titleLabel");

        mainLayout->addWidget(titleLabel);

        searchLayout = new QHBoxLayout();
        searchLayout->setSpacing(10);
        searchLayout->setObjectName("searchLayout");
        searchLayout->setContentsMargins(-1, -1, -1, 20);
        searchEdit = new QLineEdit(StaffView);
        searchEdit->setObjectName("searchEdit");

        searchLayout->addWidget(searchEdit);

        sortBtn = new QPushButton(StaffView);
        sortBtn->setObjectName("sortBtn");
        sortBtn->setMinimumSize(QSize(60, 42));
        sortBtn->setMaximumSize(QSize(60, 42));

        searchLayout->addWidget(sortBtn);

        newBtn = new QPushButton(StaffView);
        newBtn->setObjectName("newBtn");
        newBtn->setMinimumSize(QSize(100, 42));
        newBtn->setMaximumSize(QSize(100, 42));

        searchLayout->addWidget(newBtn);


        mainLayout->addLayout(searchLayout);

        headerLayout = new QHBoxLayout();
        headerLayout->setObjectName("headerLayout");
        headerLayout->setContentsMargins(10, -1, 10, 8);
        headerPhone = new QLabel(StaffView);
        headerPhone->setObjectName("headerPhone");
        headerPhone->setMinimumSize(QSize(150, 0));
        headerPhone->setMaximumSize(QSize(150, 16777215));
        headerPhone->setAlignment(Qt::AlignCenter);

        headerLayout->addWidget(headerPhone);

        headerSpacer1 = new QSpacerItem(20, 20, QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Minimum);

        headerLayout->addItem(headerSpacer1);

        headerName = new QLabel(StaffView);
        headerName->setObjectName("headerName");
        headerName->setAlignment(Qt::AlignCenter);

        headerLayout->addWidget(headerName);

        headerSpacer2 = new QSpacerItem(40, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        headerLayout->addItem(headerSpacer2);

        headerSpacer3 = new QSpacerItem(60, 20, QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Minimum);

        headerLayout->addItem(headerSpacer3);


        mainLayout->addLayout(headerLayout);

        staffTable = new QTableWidget(StaffView);
        if (staffTable->columnCount() < 3)
            staffTable->setColumnCount(3);
        staffTable->setObjectName("staffTable");
        staffTable->setFocusPolicy(Qt::NoFocus);
        staffTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
        staffTable->setShowGrid(false);
        staffTable->setSelectionBehavior(QAbstractItemView::SelectRows);
        staffTable->horizontalHeader()->setVisible(false);
        staffTable->verticalHeader()->setVisible(false);

        mainLayout->addWidget(staffTable);


        retranslateUi(StaffView);

        QMetaObject::connectSlotsByName(StaffView);
    } // setupUi

    void retranslateUi(QWidget *StaffView)
    {
        StaffView->setStyleSheet(QCoreApplication::translate("StaffView", "\n"
"    QLabel#titleLabel { color: #FFFFFF; font-size: 26px; font-weight: bold; }\n"
"    QLabel.headerLabel { color: #757575; font-size: 12px; font-weight: 600; }\n"
"    QLineEdit#searchEdit, QLineEdit.modalField { background-color: #3A3A3A; color: #FFFFFF; border: none; border-radius: 10px; padding: 0 14px; min-height: 42px; }\n"
"    QPushButton#sortBtn, QPushButton#newBtn { background-color: #3A3A3A; color: #FFFFFF; border: none; border-radius: 10px; font-weight: bold; }\n"
"    QTableWidget#staffTable { background-color: transparent; border: none; outline: none; }\n"
"    QTableWidget#staffTable::item { border-bottom: 1px solid rgba(255,255,255,13); }\n"
"    QTableWidget#staffTable::item:hover { background-color: #333333; }\n"
"    QWidget#addOverlay { background-color: rgba(0, 0, 0, 165); }\n"
"    QFrame#addModalCard { background-color: #2B2B2B; border: 1px solid #4A4A4A; border-radius: 14px; }\n"
"    QComboBox#positionCombo { background-color: #3A3A3A; color: white; border: none; border-radius: 10p"
                        "x; min-height: 42px; padding: 0 10px; }\n"
"    QPushButton#addPositionBtn { background-color: #3A3A3A; color: white; border: none; border-radius: 10px; font-size: 20px; }\n"
"    QPushButton.workDayBtn { background-color: #3A3A3A; color: white; border: 1px solid #3A3A3A; border-radius: 8px; min-width: 48px; max-width: 48px; min-height: 36px; }\n"
"    QPushButton.workDayBtn:checked { border: 2px solid #4A7C59; }\n"
"    QFrame#positionPanel { background-color: #333333; border-radius: 10px; }\n"
"    QPushButton#cancelAddBtn { background-color: #3A3A3A; color: #AAAAAA; border: none; border-radius: 10px; min-height: 42px; }\n"
"    QPushButton#saveAddBtn { background-color: #3A3A3A; color: white; border: 1.5px solid #4A7C59; border-radius: 10px; min-height: 42px; }\n"
"    QLabel#errorLabel, QLabel#positionErrorLabel { color: #FF6B6B; font-size: 13px; }\n"
"   ", nullptr));
        addModalTitle->setText(QCoreApplication::translate("StaffView", "\320\235\320\276\320\262\320\270\320\271 \320\277\321\200\320\260\321\206\321\226\320\262\320\275\320\270\320\272", nullptr));
        addModalTitle->setStyleSheet(QCoreApplication::translate("StaffView", "color: white; font-size: 20px; font-weight: bold;", nullptr));
        addLastNameEdit->setPlaceholderText(QCoreApplication::translate("StaffView", "\320\237\321\200\321\226\320\267\320\262\320\270\321\211\320\265 *", nullptr));
        addFirstNameEdit->setPlaceholderText(QCoreApplication::translate("StaffView", "\320\206\320\274'\321\217 *", nullptr));
        addPhoneEdit->setPlaceholderText(QCoreApplication::translate("StaffView", "\320\235\320\276\320\274\320\265\321\200 \321\202\320\265\320\273\320\265\321\204\320\276\320\275\321\203 *", nullptr));
        positionHeader->setText(QCoreApplication::translate("StaffView", "\320\237\320\236\320\241\320\220\320\224\320\220 *", nullptr));
        addPositionBtn->setText(QCoreApplication::translate("StaffView", "+", nullptr));
        newPositionTitle->setText(QCoreApplication::translate("StaffView", "\320\235\320\276\320\262\320\260 \320\277\320\276\321\201\320\260\320\264\320\260", nullptr));
        newPositionTitle->setStyleSheet(QCoreApplication::translate("StaffView", "color: #AAAAAA; font-weight: 600;", nullptr));
        newPositionNameEdit->setPlaceholderText(QCoreApplication::translate("StaffView", "\320\235\320\260\320\267\320\262\320\260 \320\277\320\276\321\201\320\260\320\264\320\270 *", nullptr));
        newPositionSalaryEdit->setPlaceholderText(QCoreApplication::translate("StaffView", "\320\227\320\260\321\200\320\277\320\273\320\260\321\202\320\260 (\320\263\321\200\320\275) *", nullptr));
        cancelPositionBtn->setText(QCoreApplication::translate("StaffView", "\320\241\320\272\320\260\321\201\321\203\320\262\320\260\321\202\320\270", nullptr));
        savePositionBtn->setText(QCoreApplication::translate("StaffView", "\320\224\320\276\320\264\320\260\321\202\320\270", nullptr));
        savePositionBtn->setStyleSheet(QCoreApplication::translate("StaffView", "border: 1.5px solid #4A6FA5;", nullptr));
        workDaysHeader->setText(QCoreApplication::translate("StaffView", "\320\240\320\236\320\221\320\236\320\247\320\206 \320\224\320\235\320\206", nullptr));
        dayMonBtn->setText(QCoreApplication::translate("StaffView", "\320\237\320\275", nullptr));
        dayTueBtn->setText(QCoreApplication::translate("StaffView", "\320\222\321\202", nullptr));
        dayWedBtn->setText(QCoreApplication::translate("StaffView", "\320\241\321\200", nullptr));
        dayThuBtn->setText(QCoreApplication::translate("StaffView", "\320\247\321\202", nullptr));
        dayFriBtn->setText(QCoreApplication::translate("StaffView", "\320\237\321\202", nullptr));
        daySatBtn->setText(QCoreApplication::translate("StaffView", "\320\241\320\261", nullptr));
        daySunBtn->setText(QCoreApplication::translate("StaffView", "\320\235\320\264", nullptr));
        hoursHeader->setText(QCoreApplication::translate("StaffView", "\320\223\320\236\320\224\320\230\320\235\320\230 \320\240\320\236\320\221\320\236\320\242\320\230", nullptr));
        startLabel->setText(QCoreApplication::translate("StaffView", "\320\237\320\276\321\207\320\260\321\202\320\276\320\272", nullptr));
        startLabel->setStyleSheet(QCoreApplication::translate("StaffView", "color: #666666; font-size: 11px;", nullptr));
        startTimeEdit->setText(QCoreApplication::translate("StaffView", "09:00", nullptr));
        hoursDash->setText(QCoreApplication::translate("StaffView", "\342\200\224", nullptr));
        hoursDash->setStyleSheet(QCoreApplication::translate("StaffView", "color: #555555; font-size: 18px;", nullptr));
        endLabel->setText(QCoreApplication::translate("StaffView", "\320\232\321\226\320\275\320\265\321\206\321\214", nullptr));
        endLabel->setStyleSheet(QCoreApplication::translate("StaffView", "color: #666666; font-size: 11px;", nullptr));
        endTimeEdit->setText(QCoreApplication::translate("StaffView", "18:00", nullptr));
        cancelAddBtn->setText(QCoreApplication::translate("StaffView", "\320\241\320\272\320\260\321\201\321\203\320\262\320\260\321\202\320\270", nullptr));
        saveAddBtn->setText(QCoreApplication::translate("StaffView", "\320\227\320\261\320\265\321\200\320\265\320\263\321\202\320\270", nullptr));
        titleLabel->setText(QCoreApplication::translate("StaffView", "\320\237\321\200\320\260\321\206\321\226\320\262\320\275\320\270\320\272\320\270", nullptr));
        searchEdit->setPlaceholderText(QCoreApplication::translate("StaffView", "\320\237\320\276\321\210\321\203\320\272 (\321\202\320\265\320\273\320\265\321\204\320\276\320\275, \321\226\320\274'\321\217, \320\277\321\200\321\226\320\267\320\262\320\270\321\211\320\265)", nullptr));
        sortBtn->setText(QCoreApplication::translate("StaffView", "\320\220 \342\206\222 \320\257", nullptr));
        newBtn->setText(QCoreApplication::translate("StaffView", "+ \320\235\320\276\320\262\320\270\320\271", nullptr));
        headerPhone->setText(QCoreApplication::translate("StaffView", "\320\242\320\225\320\233\320\225\320\244\320\236\320\235", nullptr));
        headerName->setText(QCoreApplication::translate("StaffView", "\320\237\320\240\320\206\320\227\320\222\320\230\320\251\320\225 \320\242\320\220 \320\206\320\234'\320\257", nullptr));
    } // retranslateUi

};

namespace Ui {
    class StaffView: public Ui_StaffView {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STAFFVIEW_H
