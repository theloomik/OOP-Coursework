/********************************************************************************
** Form generated from reading UI file 'stockview.ui'
**
** Created by: Qt User Interface Compiler version 6.11.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STOCKVIEW_H
#define UI_STOCKVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_StockView
{
public:
    QWidget *addOverlay;
    QVBoxLayout *vboxLayout;
    QSpacerItem *spacerItem;
    QFrame *addModalCard;
    QVBoxLayout *vboxLayout1;
    QLabel *label;
    QLineEdit *addMedicineEdit;
    QLineEdit *addPriceEdit;
    QLineEdit *addQuantityEdit;
    QComboBox *addProviderCombo;
    QLabel *errorLabel;
    QHBoxLayout *hboxLayout;
    QPushButton *cancelAddBtn;
    QPushButton *saveAddBtn;
    QSpacerItem *spacerItem1;
    QWidget *editOverlay;
    QVBoxLayout *vboxLayout2;
    QSpacerItem *spacerItem2;
    QFrame *editModalCard;
    QVBoxLayout *vboxLayout3;
    QLabel *label1;
    QLineEdit *editMedicineEdit;
    QLineEdit *editPriceEdit;
    QLineEdit *editQuantityEdit;
    QLineEdit *editMinimumEdit;
    QComboBox *editProviderCombo;
    QLabel *editErrorLabel;
    QHBoxLayout *hboxLayout1;
    QPushButton *cancelEditBtn;
    QPushButton *saveEditBtn;
    QPushButton *deleteEditBtn;
    QSpacerItem *spacerItem3;
    QVBoxLayout *mainLayout;
    QLabel *titleLabel;
    QHBoxLayout *statsLayout;
    QFrame *statCardTotal;
    QVBoxLayout *vboxLayout4;
    QLabel *label2;
    QLabel *totalPositionsLabel;
    QFrame *statCardLow;
    QVBoxLayout *vboxLayout5;
    QLabel *label3;
    QLabel *lowStockLabel;
    QFrame *statCardSuppliers;
    QVBoxLayout *vboxLayout6;
    QLabel *label4;
    QLabel *suppliersCountLabel;
    QHBoxLayout *searchLayout;
    QLineEdit *searchEdit;
    QPushButton *newBtn;
    QHBoxLayout *headerLayout;
    QPushButton *sortMedicineBtn;
    QPushButton *sortPriceBtn;
    QPushButton *sortQuantityBtn;
    QLabel *label5;
    QLabel *label6;
    QLabel *label7;
    QLabel *label8;
    QTableWidget *stockTable;

    void setupUi(QWidget *StockView)
    {
        if (StockView->objectName().isEmpty())
            StockView->setObjectName("StockView");
        addOverlay = new QWidget(StockView);
        addOverlay->setObjectName("addOverlay");
        addOverlay->setVisible(false);
        vboxLayout = new QVBoxLayout(addOverlay);
        vboxLayout->setObjectName("vboxLayout");
        vboxLayout->setContentsMargins(0, 0, 0, 0);
        spacerItem = new QSpacerItem(0, 0, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        vboxLayout->addItem(spacerItem);

        addModalCard = new QFrame(addOverlay);
        addModalCard->setObjectName("addModalCard");
        addModalCard->setMinimumSize(QSize(420, 0));
        vboxLayout1 = new QVBoxLayout(addModalCard);
        vboxLayout1->setSpacing(14);
        vboxLayout1->setObjectName("vboxLayout1");
        vboxLayout1->setContentsMargins(28, 28, 28, 28);
        label = new QLabel(addModalCard);
        label->setObjectName("label");

        vboxLayout1->addWidget(label, 0, Qt::AlignHCenter);

        addMedicineEdit = new QLineEdit(addModalCard);
        addMedicineEdit->setObjectName("addMedicineEdit");

        vboxLayout1->addWidget(addMedicineEdit);

        addPriceEdit = new QLineEdit(addModalCard);
        addPriceEdit->setObjectName("addPriceEdit");

        vboxLayout1->addWidget(addPriceEdit);

        addQuantityEdit = new QLineEdit(addModalCard);
        addQuantityEdit->setObjectName("addQuantityEdit");

        vboxLayout1->addWidget(addQuantityEdit);

        addProviderCombo = new QComboBox(addModalCard);
        addProviderCombo->setObjectName("addProviderCombo");

        vboxLayout1->addWidget(addProviderCombo);

        errorLabel = new QLabel(addModalCard);
        errorLabel->setObjectName("errorLabel");
        errorLabel->setVisible(false);

        vboxLayout1->addWidget(errorLabel);

        hboxLayout = new QHBoxLayout();
        hboxLayout->setObjectName("hboxLayout");
        cancelAddBtn = new QPushButton(addModalCard);
        cancelAddBtn->setObjectName("cancelAddBtn");

        hboxLayout->addWidget(cancelAddBtn);

        saveAddBtn = new QPushButton(addModalCard);
        saveAddBtn->setObjectName("saveAddBtn");

        hboxLayout->addWidget(saveAddBtn);


        vboxLayout1->addLayout(hboxLayout);


        vboxLayout->addWidget(addModalCard, 0, Qt::AlignHCenter);

        spacerItem1 = new QSpacerItem(0, 0, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        vboxLayout->addItem(spacerItem1);

        editOverlay = new QWidget(StockView);
        editOverlay->setObjectName("editOverlay");
        editOverlay->setVisible(false);
        vboxLayout2 = new QVBoxLayout(editOverlay);
        vboxLayout2->setObjectName("vboxLayout2");
        vboxLayout2->setContentsMargins(0, 0, 0, 0);
        spacerItem2 = new QSpacerItem(0, 0, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        vboxLayout2->addItem(spacerItem2);

        editModalCard = new QFrame(editOverlay);
        editModalCard->setObjectName("editModalCard");
        editModalCard->setMinimumSize(QSize(420, 0));
        vboxLayout3 = new QVBoxLayout(editModalCard);
        vboxLayout3->setSpacing(14);
        vboxLayout3->setObjectName("vboxLayout3");
        vboxLayout3->setContentsMargins(28, 28, 28, 28);
        label1 = new QLabel(editModalCard);
        label1->setObjectName("label1");

        vboxLayout3->addWidget(label1, 0, Qt::AlignHCenter);

        editMedicineEdit = new QLineEdit(editModalCard);
        editMedicineEdit->setObjectName("editMedicineEdit");

        vboxLayout3->addWidget(editMedicineEdit);

        editPriceEdit = new QLineEdit(editModalCard);
        editPriceEdit->setObjectName("editPriceEdit");

        vboxLayout3->addWidget(editPriceEdit);

        editQuantityEdit = new QLineEdit(editModalCard);
        editQuantityEdit->setObjectName("editQuantityEdit");

        vboxLayout3->addWidget(editQuantityEdit);

        editMinimumEdit = new QLineEdit(editModalCard);
        editMinimumEdit->setObjectName("editMinimumEdit");

        vboxLayout3->addWidget(editMinimumEdit);

        editProviderCombo = new QComboBox(editModalCard);
        editProviderCombo->setObjectName("editProviderCombo");

        vboxLayout3->addWidget(editProviderCombo);

        editErrorLabel = new QLabel(editModalCard);
        editErrorLabel->setObjectName("editErrorLabel");
        editErrorLabel->setVisible(false);

        vboxLayout3->addWidget(editErrorLabel);

        hboxLayout1 = new QHBoxLayout();
        hboxLayout1->setObjectName("hboxLayout1");
        cancelEditBtn = new QPushButton(editModalCard);
        cancelEditBtn->setObjectName("cancelEditBtn");

        hboxLayout1->addWidget(cancelEditBtn);

        saveEditBtn = new QPushButton(editModalCard);
        saveEditBtn->setObjectName("saveEditBtn");

        hboxLayout1->addWidget(saveEditBtn);


        vboxLayout3->addLayout(hboxLayout1);

        deleteEditBtn = new QPushButton(editModalCard);
        deleteEditBtn->setObjectName("deleteEditBtn");

        vboxLayout3->addWidget(deleteEditBtn);


        vboxLayout2->addWidget(editModalCard, 0, Qt::AlignHCenter);

        spacerItem3 = new QSpacerItem(0, 0, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        vboxLayout2->addItem(spacerItem3);

        mainLayout = new QVBoxLayout(StockView);
        mainLayout->setObjectName("mainLayout");
        mainLayout->setContentsMargins(30, 25, 30, 25);
        titleLabel = new QLabel(StockView);
        titleLabel->setObjectName("titleLabel");

        mainLayout->addWidget(titleLabel);

        statsLayout = new QHBoxLayout();
        statsLayout->setSpacing(14);
        statsLayout->setObjectName("statsLayout");
        statsLayout->setContentsMargins(-1, -1, -1, 18);
        statCardTotal = new QFrame(StockView);
        statCardTotal->setObjectName("statCardTotal");
        statCardTotal->setFrameShape(QFrame::StyledPanel);
        vboxLayout4 = new QVBoxLayout(statCardTotal);
        vboxLayout4->setObjectName("vboxLayout4");
        label2 = new QLabel(statCardTotal);
        label2->setObjectName("label2");

        vboxLayout4->addWidget(label2);

        totalPositionsLabel = new QLabel(statCardTotal);
        totalPositionsLabel->setObjectName("totalPositionsLabel");

        vboxLayout4->addWidget(totalPositionsLabel);


        statsLayout->addWidget(statCardTotal);

        statCardLow = new QFrame(StockView);
        statCardLow->setObjectName("statCardLow");
        vboxLayout5 = new QVBoxLayout(statCardLow);
        vboxLayout5->setObjectName("vboxLayout5");
        label3 = new QLabel(statCardLow);
        label3->setObjectName("label3");

        vboxLayout5->addWidget(label3);

        lowStockLabel = new QLabel(statCardLow);
        lowStockLabel->setObjectName("lowStockLabel");

        vboxLayout5->addWidget(lowStockLabel);


        statsLayout->addWidget(statCardLow);

        statCardSuppliers = new QFrame(StockView);
        statCardSuppliers->setObjectName("statCardSuppliers");
        vboxLayout6 = new QVBoxLayout(statCardSuppliers);
        vboxLayout6->setObjectName("vboxLayout6");
        label4 = new QLabel(statCardSuppliers);
        label4->setObjectName("label4");

        vboxLayout6->addWidget(label4);

        suppliersCountLabel = new QLabel(statCardSuppliers);
        suppliersCountLabel->setObjectName("suppliersCountLabel");

        vboxLayout6->addWidget(suppliersCountLabel);


        statsLayout->addWidget(statCardSuppliers);


        mainLayout->addLayout(statsLayout);

        searchLayout = new QHBoxLayout();
        searchLayout->setObjectName("searchLayout");
        searchLayout->setContentsMargins(-1, -1, -1, 20);
        searchEdit = new QLineEdit(StockView);
        searchEdit->setObjectName("searchEdit");

        searchLayout->addWidget(searchEdit);

        newBtn = new QPushButton(StockView);
        newBtn->setObjectName("newBtn");

        searchLayout->addWidget(newBtn);


        mainLayout->addLayout(searchLayout);

        headerLayout = new QHBoxLayout();
        headerLayout->setObjectName("headerLayout");
        sortMedicineBtn = new QPushButton(StockView);
        sortMedicineBtn->setObjectName("sortMedicineBtn");

        headerLayout->addWidget(sortMedicineBtn);

        sortPriceBtn = new QPushButton(StockView);
        sortPriceBtn->setObjectName("sortPriceBtn");

        headerLayout->addWidget(sortPriceBtn);

        sortQuantityBtn = new QPushButton(StockView);
        sortQuantityBtn->setObjectName("sortQuantityBtn");

        headerLayout->addWidget(sortQuantityBtn);

        label5 = new QLabel(StockView);
        label5->setObjectName("label5");

        headerLayout->addWidget(label5);

        label6 = new QLabel(StockView);
        label6->setObjectName("label6");

        headerLayout->addWidget(label6);

        label7 = new QLabel(StockView);
        label7->setObjectName("label7");

        headerLayout->addWidget(label7);

        label8 = new QLabel(StockView);
        label8->setObjectName("label8");

        headerLayout->addWidget(label8);


        mainLayout->addLayout(headerLayout);

        stockTable = new QTableWidget(StockView);
        if (stockTable->columnCount() < 7)
            stockTable->setColumnCount(7);
        stockTable->setObjectName("stockTable");
        stockTable->setFocusPolicy(Qt::NoFocus);
        stockTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
        stockTable->setShowGrid(false);
        stockTable->setSelectionBehavior(QAbstractItemView::SelectRows);
        stockTable->horizontalHeader()->setVisible(false);
        stockTable->verticalHeader()->setVisible(false);

        mainLayout->addWidget(stockTable);


        retranslateUi(StockView);

        QMetaObject::connectSlotsByName(StockView);
    } // setupUi

    void retranslateUi(QWidget *StockView)
    {
        StockView->setStyleSheet(QCoreApplication::translate("StockView", "\n"
"    QLabel#titleLabel { color: #FFFFFF; font-size: 26px; font-weight: bold; }\n"
"    QLabel.headerLabel, QPushButton.sortHeaderBtn { color: #757575; font-size: 12px; font-weight: 600; border: none; background: transparent; }\n"
"    QFrame.statCard { background-color: #2E2E2E; border-radius: 12px; }\n"
"    QLabel.statValue { color: white; font-size: 22px; font-weight: bold; }\n"
"    QLabel#lowStockValue { color: #FF8C8C; }\n"
"    QLineEdit#searchEdit, QLineEdit.modalField { background-color: #3A3A3A; color: #FFFFFF; border: none; border-radius: 10px; padding: 0 14px; min-height: 42px; }\n"
"    QPushButton#newBtn { background-color: #3A3A3A; color: #FFFFFF; border: none; border-radius: 10px; min-width: 118px; min-height: 42px; }\n"
"    QTableWidget#stockTable { background-color: transparent; border: none; outline: none; color: white; }\n"
"    QTableWidget#stockTable::item { border-bottom: 1px solid rgba(255,255,255,13); padding: 6px; }\n"
"    QWidget#addOverlay, QWidget#editOverlay { background-col"
                        "or: rgba(0, 0, 0, 165); }\n"
"    QFrame.modalCard { background-color: #2B2B2B; border: 1px solid #4A4A4A; border-radius: 14px; }\n"
"    QComboBox.modalCombo { background-color: #3A3A3A; color: white; border: none; border-radius: 10px; min-height: 42px; }\n"
"    QPushButton#cancelAddBtn, QPushButton#cancelEditBtn { background-color: #3A3A3A; color: #D0D0D0; border: none; border-radius: 12px; min-height: 44px; }\n"
"    QPushButton#saveAddBtn, QPushButton#saveEditBtn { background-color: #2ECC71; color: white; border: 1px solid #76E2A0; border-radius: 12px; min-height: 44px; font-weight: bold; }\n"
"    QPushButton#deleteEditBtn { background-color: #7C4A4A; color: white; border: none; border-radius: 12px; min-height: 44px; }\n"
"    QLabel#errorLabel, QLabel#editErrorLabel { color: #FF6B6B; }\n"
"   ", nullptr));
        label->setText(QCoreApplication::translate("StockView", "\320\235\320\276\320\262\320\270\320\271 \320\277\321\200\320\265\320\277\320\260\321\200\320\260\321\202", nullptr));
        label->setStyleSheet(QCoreApplication::translate("StockView", "color:white;font-size:20px;font-weight:bold;", nullptr));
        addMedicineEdit->setPlaceholderText(QCoreApplication::translate("StockView", "\320\235\320\260\320\267\320\262\320\260 \320\277\321\200\320\265\320\277\320\260\321\200\320\260\321\202\321\203 *", nullptr));
        addPriceEdit->setPlaceholderText(QCoreApplication::translate("StockView", "\320\246\321\226\320\275\320\260 \320\277\321\200\320\276\320\264\320\260\320\266\321\203 *", nullptr));
        addQuantityEdit->setText(QCoreApplication::translate("StockView", "1", nullptr));
        addQuantityEdit->setPlaceholderText(QCoreApplication::translate("StockView", "\320\232\321\226\320\273\321\214\320\272\321\226\321\201\321\202\321\214 *", nullptr));
        cancelAddBtn->setText(QCoreApplication::translate("StockView", "\320\241\320\272\320\260\321\201\321\203\320\262\320\260\321\202\320\270", nullptr));
        saveAddBtn->setText(QCoreApplication::translate("StockView", "\320\227\320\261\320\265\321\200\320\265\320\263\321\202\320\270", nullptr));
        label1->setText(QCoreApplication::translate("StockView", "\320\240\320\265\320\264\320\260\320\263\321\203\320\262\320\260\321\202\320\270 \320\277\320\276\320\267\320\270\321\206\321\226\321\216", nullptr));
        label1->setStyleSheet(QCoreApplication::translate("StockView", "color:white;font-size:20px;font-weight:bold;", nullptr));
        editMinimumEdit->setPlaceholderText(QCoreApplication::translate("StockView", "\320\234\321\226\320\275\321\226\320\274\320\260\320\273\321\214\320\275\320\270\320\271 \320\267\320\260\320\273\320\270\321\210\320\276\320\272", nullptr));
        cancelEditBtn->setText(QCoreApplication::translate("StockView", "\320\241\320\272\320\260\321\201\321\203\320\262\320\260\321\202\320\270", nullptr));
        saveEditBtn->setText(QCoreApplication::translate("StockView", "\320\227\320\261\320\265\321\200\320\265\320\263\321\202\320\270", nullptr));
        deleteEditBtn->setText(QCoreApplication::translate("StockView", "\320\222\320\270\320\264\320\260\320\273\320\270\321\202\320\270", nullptr));
        titleLabel->setText(QCoreApplication::translate("StockView", "\320\241\320\272\320\273\320\260\320\264", nullptr));
        label2->setText(QCoreApplication::translate("StockView", "\320\232\320\206\320\233\320\254\320\232\320\206\320\241\320\242\320\254 \320\237\320\236\320\227\320\230\320\246\320\206\320\231", nullptr));
        totalPositionsLabel->setText(QCoreApplication::translate("StockView", "0", nullptr));
        label3->setText(QCoreApplication::translate("StockView", "\320\235\320\230\320\227\320\254\320\232\320\230\320\231 \320\227\320\220\320\237\320\220\320\241", nullptr));
        lowStockLabel->setText(QCoreApplication::translate("StockView", "0", nullptr));
        label4->setText(QCoreApplication::translate("StockView", "\320\237\320\236\320\241\320\242\320\220\320\247\320\220\320\233\320\254\320\235\320\230\320\232\320\230", nullptr));
        suppliersCountLabel->setText(QCoreApplication::translate("StockView", "0", nullptr));
        searchEdit->setPlaceholderText(QCoreApplication::translate("StockView", "\320\237\320\276\321\210\321\203\320\272 (\320\275\320\260\320\267\320\262\320\260 \320\277\321\200\320\265\320\277\320\260\321\200\320\260\321\202\321\203, \320\277\320\276\321\201\321\202\320\260\321\207\320\260\320\273\321\214\320\275\320\270\320\272)", nullptr));
        newBtn->setText(QCoreApplication::translate("StockView", "+ \320\235\320\276\320\262\320\270\320\271", nullptr));
        sortMedicineBtn->setText(QCoreApplication::translate("StockView", "\320\237\320\240\320\225\320\237\320\220\320\240\320\220\320\242", nullptr));
        sortPriceBtn->setText(QCoreApplication::translate("StockView", "\320\246\320\206\320\235\320\220", nullptr));
        sortQuantityBtn->setText(QCoreApplication::translate("StockView", "\320\232\320\206\320\233\320\254\320\232\320\206\320\241\320\242\320\254", nullptr));
        label5->setText(QCoreApplication::translate("StockView", "\320\234\320\206\320\235. \320\227\320\220\320\233\320\230\320\250\320\236\320\232", nullptr));
        label6->setText(QCoreApplication::translate("StockView", "\320\237\320\236\320\241\320\242\320\220\320\247\320\220\320\233\320\254\320\235\320\230\320\232", nullptr));
        label7->setText(QCoreApplication::translate("StockView", "\320\237\320\236\320\237\320\236\320\222\320\235\320\225\320\235\320\236", nullptr));
        label8->setText(QCoreApplication::translate("StockView", "\320\224\320\206\320\207", nullptr));
    } // retranslateUi

};

namespace Ui {
    class StockView: public Ui_StockView {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STOCKVIEW_H
